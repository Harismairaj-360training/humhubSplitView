<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 03:50
 */

return array (
    'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => 'Hier können sie ihre Vorlagen Layouts verwalten. Layouts sind das Grundgerüst für Ihre Vorlagen Seiten und können nicht mit anderen Inhalten kombiniert werden.',
);