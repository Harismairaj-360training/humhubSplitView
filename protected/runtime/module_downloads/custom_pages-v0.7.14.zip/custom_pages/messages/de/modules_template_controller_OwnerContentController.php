<?php
/**
 * Created by PhpStorm.
 * User: pling
 * Date: 25.01.2017
 * Time: 02:13
 */
return array (
    '<strong>Confirm</strong> container item deletion' => '<strong>Bestätige</strong> das Löschen des Content Elements',
);
