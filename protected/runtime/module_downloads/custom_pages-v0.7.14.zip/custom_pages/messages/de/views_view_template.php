<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 02:59
 */

return array (
    'Edit Template' => 'Vorlage bearbeiten',

);