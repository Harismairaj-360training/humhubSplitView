<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 01:21
 */
return array (

    'ID' => 'ID',
    'Type' => 'Typ',
    'Title' => 'Titel',
    'Icon' => 'Symbol',
    'Style Class' => 'Style Klasse',
    'Content' => 'Inhalt',
    'Template Layout' => 'Vorlagen Layout',
    'Sort Order' => 'Sortierung',
    'Target Url' => 'Ziel URL',
    'Only visible for admins' => 'Nur für Admins sichtbar',
    'Without adding to navigation (Direct link)' => 'Ohne zur Navigation hinzufügen (Direktlink)',
);