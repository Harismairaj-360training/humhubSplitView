<?php
return array (
  '<strong>Add</strong> new page' => '<strong>Legg til</strong> ny side',
);
