<?php
return array (
  'Open page...' => 'Åpne side...',
);
