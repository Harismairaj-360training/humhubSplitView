<?php
return array (
  'Allows to add pages (markdown, iframe or links) to the space navigation' => '',
  'Create new Page' => 'Lag en ny Side',
  'Custom Pages' => '',
  'Custom pages' => '',
  'HTML' => 'HTML',
  'IFrame' => '',
  'Link' => 'Link',
  'MarkDown' => '',
  'Navigation' => 'Navigasjon',
  'No custom pages created yet!' => 'Ingen egen definerte sider laget enda!',
  'Sort Order' => 'Sorterings Rekkefølge',
  'Title' => 'Tittel',
  'Top Navigation' => 'Top Navigering',
  'Type' => 'Type',
  'User Account Menu (Settings)' => 'Bruker konto meny (Innstillinger)',
  'Without adding to navigation (Direct link)' => '',
);
